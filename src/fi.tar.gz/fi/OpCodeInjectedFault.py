from m5.params import *
from O3CPUInjectedFault import O3CPUInjectedFault

class OpCodeInjectedFault(O3CPUInjectedFault):
    type = 'OpCodeInjectedFault'






