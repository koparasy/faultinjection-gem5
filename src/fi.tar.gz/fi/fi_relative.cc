#include "fi/fi_relative.hh"

FI_Inst fi_inst;
