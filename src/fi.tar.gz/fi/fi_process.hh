#ifndef __FI_PROCESS_HH__
#define __FI_PROCESS_HH__

#include "config/full_system.hh"
//using namespace std;

//extern std::string c_pname;
//extern int c_pid;



#endif //__FI_PROCESS_HH__
