from m5.params import *
from O3CPUInjectedFault import O3CPUInjectedFault

class GeneralFetchInjectedFault(O3CPUInjectedFault):
    type = 'GeneralFetchInjectedFault'






