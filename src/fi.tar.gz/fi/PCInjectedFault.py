from m5.params import *
from CPUInjectedFault import CPUInjectedFault

class PCInjectedFault(CPUInjectedFault):
    type = 'PCInjectedFault'






