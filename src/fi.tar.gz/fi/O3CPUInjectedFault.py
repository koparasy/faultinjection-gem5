from m5.params import *
from InjectedFault import InjectedFault

class O3CPUInjectedFault(InjectedFault):
    type = 'O3CPUInjectedFault'

    tcontext = Param.Int(0, "Example Num") 





