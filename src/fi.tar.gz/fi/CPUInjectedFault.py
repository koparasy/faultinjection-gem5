from m5.params import *
from InjectedFault import InjectedFault

class CPUInjectedFault(InjectedFault):
    type = 'CPUInjectedFault'

    tcontext = Param.Int(0, "Example Num") 





