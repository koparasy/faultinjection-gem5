#ifndef __OPCODE_INJECTED_FAULT_HH__
#define __OPCODE_INJECTED_FAULT_HH__

#include "config/the_isa.hh"
#include "base/types.hh"
#include "fi/faultq.hh"
#include "fi/o3cpu_injfault.hh"
#include "cpu/o3/cpu.hh"
#include "params/OpCodeInjectedFault.hh"

class OpCodeInjectedFaultParams;

class OpCodeInjectedFault : public O3CPUInjectedFault
{

public:

  typedef OpCodeInjectedFaultParams Params;
  
  const Params *params() const
  {
    return reinterpret_cast<const Params *>(_params); 
  } 

  OpCodeInjectedFault(Params *params);
  ~OpCodeInjectedFault();

  const std::string name() const;  
  virtual const char *description() const;
  
  void dump() const;

  virtual void init();
  virtual void startup();
  
  TheISA::MachInst process(TheISA::MachInst inst);


  void check4reschedule();


};

#endif // __OPCODE_INJECTED_FAULT_HH__
