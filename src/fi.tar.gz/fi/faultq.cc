
#include <iostream>
#include <string>
#include <vector>

#include "fi/faultq.hh"

using namespace std;

InjectedFaultQueue mainInjectedFaultQueue("Main Fault Queue");
InjectedFaultQueue fetchStageInjectedFaultQueue("Fetch Stage Fault Queue");
InjectedFaultQueue decodeStageInjectedFaultQueue("Decode Stage Fault Queue");
InjectedFaultQueue iewStageInjectedFaultQueue("IEW Stage Fault Queue");


/*
 * used with older implementations
 */
//std::string c_pname;
//int c_pid;

std::map<Addr, bool> fi_activation;
std::map<Addr, bool>::iterator fi_activation_iter;

bool fi_active = false;



Addr MagicInstVirtualAddr = 0;
uint64_t MagicInstInstCnt = 0;
int64_t  MagicInstTickCnt = 0;


InjectedFault::InjectedFault(Params *p)
  : MemObject(p), manifested(false), nxt(NULL), prv(NULL)
{
  setFaultID();

  setWhen(p->when);
  setWhere(p->where);
  setWhat(p->what);

  setRelative(p->relative);

  setOccurrence(p->occurrence);

  int ret;
  ret = parseWhen(p->when);
  if (ret != 0) {
    std::cout << "InjectedFault::InjectedFault() -- Error while parsing When\n";
    assert(0);
  }
  ret = parseWhat(p->what);
  if (ret != 0) {
    std::cout << "InjectedFault::InjectedFault() -- Error while parsing What\n";
    assert(0);
  }

}

InjectedFault::~InjectedFault()
{
  getQueue()->remove(this);
}

const std::string
InjectedFault::name() const
{
  return params()->name;
}

const char *
InjectedFault::description() const
{
    return "InjectedFault";
}

void
InjectedFault::init()
{
  if (DTRACE(FaultInjection)) {
    std::cout << "InjectedFault:init()\n";
  }
}

void
InjectedFault::startup()
{
  if (DTRACE(FaultInjection)) {
    std::cout << "InjectedFault:startup()\n";
  }

  dump();
}

InjectedFault *
InjectedFaultParams::create()
{
  if (DTRACE(FaultInjection)) {
    std::cout << "InjectedFaultParams:create()\n";
  }
  
  return new InjectedFault(this);
}


Port *
InjectedFault::getPort(const string &if_name, int idx)
{
  std::cout << "InjectedFault:getPort() " << "if_name: " << if_name << " idx: " << idx <<  "\n";
  panic("No Such Port\n");
}


int
InjectedFault::parseWhen(std::string s)
{
  if (s.compare(0,4,"Inst",0,4) == 0) {
    setTimingType(InjectedFault::InstructionTiming);
    setTiming(s.substr(5));
  }
  else if (s.compare(0,4,"Tick",0,4) == 0) {
    setTimingType(InjectedFault::TickTiming);
    setTiming(s.substr(5));
  }
  else if (s.compare(0,4,"Addr",0,4) == 0) {
    setTimingType(InjectedFault::VirtualAddrTiming);
    setTiming(s.substr(5));
  }
  else {
    std::cout << "InjecteFault::parseWhen() - Error Unsupported type " << s << "\n";
    assert(0);
    return 1;
  }
  
  return 0;
}

int
InjectedFault::parseWhat(std::string s)
{
  if (s.compare(0,4,"Immd",0,4) == 0) {
    setValueType(InjectedFault::ImmediateValue);
    setValue(s.substr(5));
  }
  else if (s.compare(0,4,"Mask",0,4) == 0) {
    setValueType(InjectedFault::MaskValue);
    setValue(s.substr(5));
  }
  else if (s.compare(0,4,"Flip",0,4) == 0) {
    setValueType(InjectedFault::FlipBit);
    setValue(s.substr(5));
  }
  else if (s.compare(0,4,"All0",0,4) == 0) {
    setValueType(InjectedFault::AllValue);
    setValue(0);
  }
  else if (s.compare(0,4,"All1",0,4) == 0) {
    setValueType(InjectedFault::AllValue);
    setValue(1);
  }
  else {
    std::cout << "InjectedFault::parseWhat() - Error Unsupported type " << s << "\n";
    assert(0);
    return 1;
  }
  
  return 0;
}

void 
InjectedFault::increaseTiming(uint64_t cycles, uint64_t insts, uint64_t addr)
{
  switch (getTimingType())
    {
    case (InjectedFault::TickTiming):
      {
	setTiming(cycles);
	break;
      }
    case (InjectedFault::InstructionTiming):
      {
	  setTiming(insts);
	  break;
      }
    case (InjectedFault::VirtualAddrTiming):
      {
	/*Originally this changed to a different timing type, however, we will keep it at the same type to enable the precise injection of permanent faults (e.g. first value of a macroblock)
	 */


	/* Virtual addresses can not be used for non transient faults, that is because in the presence of branches we can not predefine an address for the next fault to occure (will the branch succeed or not).
	   For that reason we change the Timing Type either the Tick or Instruction can be used, one can add an option but currently instructions are choosen no thought was put onto that choice.
	 */
	//setTimingType(InjectedFault::InstructionTiming);
	//setTiming(insts);
	
	/*we also remove the fault from the fault queue as it was done for the other types too
	 */
	//getQueue()->remove(this);
	
	break;
      }
    default:
      {
	std::cout << "InjectedFault::increaseTiming() - getTimingType default type error\n";
	assert(0);
	break;
      }
    }
}



void
InjectedFault::dump() const
{
  if (DTRACE(FaultInjection)) {
    std::cout << "===InjectedFault::dump()===\n";
    std::cout << "\tWhere: " << getWhere() << "\n";
    std::cout << "\tWhen: " << getWhen() << "\n";
    std::cout << "\tWhat: " << getWhat() << "\n";
    std::cout << "\tfaultID: " << getFaultID() << "\n";
    std::cout << "\tfaultType: " << getFaultType() << "\n";
    std::cout << "\ttimingType: " << getTimingType() << "\n";
    std::cout << "\ttiming: " << getTiming() << "\n";
    std::cout << "\trelative: " << getRelative() << "\n";
    std::cout << "\tvalueType: " << getValueType() << "\n";
    std::cout << "\tvalue: " << getValue() << "\n";
    std::cout << "\toccurrence: " << getOccurrence() << "\n";
    std::cout << "~==InjectedFault::dump()===\n";
  }
}


InjectedFaultQueue::InjectedFaultQueue(const string &n)
  : objName(n), head(NULL), tail(NULL)
{
  //warning
  // causes segmentation fault
  //if (DTRACE(FaultInjection)) {
  //std::cout << "InjectedFaultQueue::InjectedFaultQueue()\n";
  //}
}


void
InjectedFaultQueue::insert(InjectedFault *f)
{
  f->setQueue(this); // when inserting a fault to a queue place a reference from it to the queue

  InjectedFault *p;

  p = head;
  
  if (empty()) {//queue is empty
    head = f;
    tail = f;
    return;
  }
  else {//queue is not empty
    while ((p!=NULL) && (p->getTiming() < f->getTiming())) {//travel queue elements to find the one before which our element will be inserted
      p = p->nxt;
    }
    
    if (p==NULL) {//element inserted at the end
      tail->nxt = f;
      f->prv = tail;
      tail = f;
      return;
    }
    else if (p==head) {//element inserted in the beginning
      head->prv = f;
      f->nxt = head;
      head = f;
      return;
    }
    else {//element inserted between two other elements
      p->prv->nxt = f;
      f->prv = p->prv;
      p->prv =f;
      f->nxt = p;
      return;
    }
  }

}

void
InjectedFaultQueue::remove(InjectedFault *f)
{
  InjectedFault *p;


  if ((head==NULL) & (tail==NULL)) {//queue is empty
    return;
  }

  p = head;
  while ((p!=NULL) && (p!=f)) {//search if event exists
    p = p->nxt;
  }

  if (p==NULL) {//event was not found
    std::cout << "InjectedFaultQueue:remove() -- Fault was not found on the queue\n";
    assert(0);
  }

  if (f->prv==NULL) {//fault to be removed is the first one
    head = f->nxt;
  }
  else {
    f->prv->nxt = f->nxt;
  }

  if (f->nxt==NULL) {//fault to be removed is the last one
    tail = f->prv;
  }
  else {
    f->nxt->prv = f->prv;
  }

  return;

}

/*
//Older version kept just in case :)

InjectedFault *
InjectedFaultQueue::scan2(std::string s, int64_t t, uint64_t instCnt, Addr vaddr)
{
  InjectedFault *p;

  //std::cout << name()<< " scan called: " << t << " # " << instCnt << "\n";
  p = head;
  
  while (p != NULL) {
    if (!p->getWhere().compare(s)) {
      if (p->getTimingType() == InjectedFault::TickTiming) {
	if (getRelative()) {
	  if (MagicInstTickCnt + p->getTiming() == t) {
	    return p;
	  }
	}
	else {
	  if (p->getTiming() == t) {
	    return p;
	  }
	}
      }
      else if (p->getTimingType() == InjectedFault::InstructionTiming) {
	if (getRelative()) {
	  if (MagicInstInstCnt + p->getTiming() == instCnt) {
	    return p;
	  }
	}
	else {
	  if (p->getTiming() == instCnt) {
	    return p;
	  }
	}
      }
      else if (p->getTimingType() == InjectedFault::VirtualAddrTiming) {
	if (getRelative()) {
	  if (MagicInstVirtualAddr + p->getTiming() == vaddr) {
	    return p;
	  }
	}
	else {
	  if (p->getTiming() == vaddr) {
	    return p;
	  }
	}
      } 
    }
    else {
      std::cout << "NOTELEMENT: ";
      std::cout << p->getWhere() << " : " << s << "\n";
      std::cout << name() << " Tick: " << t << " instCnt: " << instCnt << "\n";
    }
    p = p->nxt;
  }

  return NULL;
}
*/


InjectedFault *
InjectedFaultQueue::scan(std::string s, int64_t t, uint64_t instCnt, Addr vaddr)
{
  InjectedFault *p;

  p = head;



  while (p != NULL) {
    if (!p->getWhere().compare(s)) {//check for correct module
      if (p->getServicedAt() != t) {//check if it has already been scheduled for this cycle
	switch (p->getTimingType()) {//Timing type switch
	case (InjectedFault::TickTiming) :
	  {
	    if (p->getRelative()) {
	      if (MagicInstTickCnt + p->getTiming() == t) {
		p->setServicedAt(t);
		return p;
	      }
	    }
	    else {
	      if (p->getTiming() == t) {
		p->setServicedAt(t);
		return p;
	      }
	    }
	  }
	  break;
	case (InjectedFault::InstructionTiming) :
	  {
	    if (p->getRelative()) {
	      if (MagicInstInstCnt + p->getTiming() == instCnt) {
		p->setServicedAt(t);
		return p;
	      }
	    }
	    else {
	      if (p->getTiming() == instCnt) {
		p->setServicedAt(t);
		return p;
	      }
	    }
	  }
	  break;
	case (InjectedFault::VirtualAddrTiming) :
	  {
	    if (p->getRelative()) {
	      if (MagicInstVirtualAddr + p->getTiming() == vaddr) {
		p->setServicedAt(t);
		return p;
	      }
	    }
	    else {
	      if (p->getTiming() == vaddr) {
		p->setServicedAt(t);
		return p;
	      }
	    }
	  }
	  break;
	default:
	  {
	    std::cout << "InjectedFaultQueue::scan() - getTimingType default type error\n";
	    assert(0);
	    break;
	  }
	}
      }
    }
    p = p->nxt;
  }
  

  return NULL;
}

void
InjectedFaultQueue::scheduleRelativeFaults(std::string s)
{
  InjectedFault *p;

  DPRINTF(FaultInjection, "===InjectedFaultQueue::scheduleRelativeFaults===\n");

  p = head;

  while (p != NULL) {
    if (!p->getWhere().compare(s) && p->getRelative()) {//check module name
      DPRINTF(FaultInjection, "Scheduling Fault: %d\n",p->getFaultID());
      switch (p->getTimingType()) //Timing type switch
	  {
	  case (InjectedFault::TickTiming):
	    {
	      p->setTiming(MagicInstTickCnt + p->getTiming());
	      p->setRelative(false);
	      p->schedule(true);
	      break;
	    }
	  case (InjectedFault::InstructionTiming):
	    {
	      p->setTiming(MagicInstInstCnt + p->getTiming());
	      p->setRelative(false);
	      p->schedule(true);
	      break;
	    }
	  case (InjectedFault::VirtualAddrTiming):
	    {
	      /*
		Currently this is not supported, not event queue make use of Virtual addresses as a timing mechanism. Maybe we shouldn't even change the relative status and timing value of the fault.
		Note: Need to reconsider that.
	      */
	      p->setTiming(MagicInstVirtualAddr + p->getTiming());
	      p->setRelative(false);
	      break;
	    }
	  default:
	    {
	      std::cout << "InjectedFaultQueue::scheduleRelativeFaults() - getTimingType default type error\n";
	      assert(0);
	      break;
	    }
	  }
      //p->dump();
    }
    p = p->nxt;
  }

  DPRINTF(FaultInjection, "~==InjectedFaultQueue::scheduleRelativeFaults===\n");
}



void
InjectedFaultQueue::dump() const
{
  InjectedFault *p=head;

  if (DTRACE(FaultInjection)) {
    std::cout << "=====InjectedFaultQueue::dump()=====\n";
    while (p) {
      p->dump();
      p = p->nxt;
    }
    std::cout << "~====InjectedFaultQueue::dump()=====\n";
  }
}
